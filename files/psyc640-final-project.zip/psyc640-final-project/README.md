# Project title

**Author(s):**

## Question

One or two sentences.

## Dataset

- **Source and link:**
- **Citation:**
- **License:**

## How to reproduce

Open `project.Rproj`, then render `split.qmd` (it only checks the holdout), `wrangle.qmd`, and `memo.qmd`, in that order. Do not open `data/holdout.csv`.

## Holdout statement

- **Seed and split date:** (from `holdout_checksum.txt`)
- **Zenodo DOI:**
- **Holdout md5:** (from `holdout_checksum.txt`)
- **Statement:** No one has opened or analyzed `data/holdout.csv`. (If that's not true, say what happened. Honesty here is graded; a peek is not.)

## Open questions for next semester

Weaknesses you can see but this course doesn't equip you to fix. Name the specific measure, confound or population.

-

## AI use

Each tool you used and what for (e.g., "Claude: debugging the scoring code in clean.R"). "None" is a fine answer.

-

## Fixes after the reproducibility swap

What broke on your swap partner's computer, and what you changed.

-

## Contribution statements (pairs only)

-
