# Start here: PSYC 640 final project

This folder becomes your final submission. You'll take a public dataset from raw file to an exploratory model, one milestone at a time. Everything is a Quarto file, like your labs.

## The files

| File | What it does | When |
|------|--------------|------|
| `split.qmd` | Splits your data 30/70 and fingerprints the holdout | M2 |
| `wrangle.qmd` | Raw data to analysis-ready: audit, your wrangling steps, codebook. Saves the analytic data | M2 |
| `memo.qmd` | Your memo: wrangling, description, model building, and the plan for the holdout | M3, final |
| `README.md` | Dataset, holdout statement, open questions, AI use | Final |

## Setup (once, 10 minutes)

1. Unzip the folder and rename it (e.g., `burnout-project`).
2. Open it by double-clicking `project.Rproj`. Always open the project this way.
3. Install packages: `install.packages(c("tidyverse", "rio", "here", "psych", "datawizard"))`
4. Render `memo.qmd`. It should produce a nearly empty document with no errors. If it errors, fix that now, not on Dec 10.

## Two rules

- **Never open `data/holdout.csv`.** Not in R, not in Excel, not in an AI tool. It's for next semester.
- **Everything happens in code.** Never edit a data file by hand.

## M1: Dataset pitch (Fri Nov 6)

No code. Pitch two candidate datasets, and say whether you're working alone or with a partner.

## M2: Split and wrangle (Sun Nov 15)

1. **Split.** Put your raw data file in `data/raw/`, but don't look at the outcome yet. In `split.qmd`, set the three settings lines, then render. This creates `data/explore.csv`, `data/holdout.csv`, and `holdout_checksum.txt`.
2. **Timestamp.** Log in at [zenodo.org](https://zenodo.org) (ORCID or GitHub works) and click **New upload**. Upload only `split.qmd` and `holdout_checksum.txt`; **never data**. Set the resource type to Other, the title to "Holdout commitment: [your title]", and the license to CC BY 4.0. Click **Publish**, then copy the DOI into `README.md`.
3. **Wrangle.** In `wrangle.qmd`, audit your variables, then add whatever steps your data need (recoding, exclusions, scale scores, joining files, aggregating trials), each under its own heading with a sentence on why. The Toolbox at the bottom has code to copy. Keep every section marked REQUIRED.
4. **Submit** the rendered `wrangle.qmd` and your Zenodo DOI.

## M3: Describe and build an initial model (Mon Nov 30)

1. In `memo.qmd`, replace the example variable names with yours, and copy chunks for any extra variables.
2. Fill in the description: descriptives, category counts, correlations and heat map, distributions, and the focal plot. Then write what they show.
3. Fit Model 1, check its diagnostics, and interpret it.
4. **Submit** the rendered memo. Rough prose is fine.

## After M3: finish the model (by Dec 11)

1. Add planned blocks (Model 2, maybe Model 3) and compare each with `anova()`.
2. Set `final` to your chosen model, check its diagnostics, and interpret it.
3. Log each step, and why you took it, in the appendix.
4. Write the plan for the holdout, the memo's last section: the final model, the decision rule, power, and where each decision came from.

## M4: Reproducibility swap (Thu Dec 3, in class)

1. Before class, copy your folder, **delete `data/holdout.csv` from the copy**, and zip the copy.
2. In class, trade zips with your assigned partner. Render theirs without help, and write down every problem before you try to fix anything.
3. Fix your own project, and list the fixes in your README.

## Final (Fri Dec 11)

Zip the whole folder, **including** the unopened `data/holdout.csv`. Before you submit:

- [ ] Restart R (Session > Restart R), then render `split.qmd`, `wrangle.qmd`, and `memo.qmd` in that order. All three work, and `split.qmd` says MATCH.
- [ ] The codebook in `wrangle.qmd` covers every variable you used or created.
- [ ] The memo includes the plan for the holdout, and `README.md` is filled in, including AI use and your post-swap fixes.

## When something breaks

| Problem | Usually the fix |
|---------|-----------------|
| "cannot open file" or "does not exist" | You opened the `.qmd` without opening `project.Rproj` first |
| "object not found" | An example name (`outcome`, `predictor`) is still in the code, or a variable was created in the console instead of the file |
| `memo.qmd` is empty | Render `wrangle.qmd` first; it saves the data the memo uses |
| "could not find function" | A package isn't installed or loaded; check Setup step 3 |

**AI tools** are allowed for debugging, explanations, and light editing, never with the holdout. The full policy is in the project description.
